#include "liste_entiers.h"

int main() {
  cellule_t *ma_liste=creerListe(5);
  AfficherListeInt(ma_liste);
  return 0;
}